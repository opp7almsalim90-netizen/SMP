#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

if [ ! -d world ]; then
  echo "No world folder found. Start the server and generate the world first." >&2
  exit 1
fi

mkdir -p backups
stamp="$(date +%Y-%m-%d_%H-%M-%S)"
echo "IMPORTANT: For a consistent backup, stop the server before running this script."
tar -czf "backups/world-${stamp}.tar.gz" world
echo "Backup created: backups/world-${stamp}.tar.gz"
