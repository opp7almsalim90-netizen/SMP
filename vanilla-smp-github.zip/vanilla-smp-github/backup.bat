@echo off
setlocal
cd /d "%~dp0"

if not exist "world" (
  echo No world folder found. Start the server and generate the world first.
  pause
  exit /b 1
)

if not exist "backups" mkdir backups
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH-mm-ss"') do set STAMP=%%i

echo IMPORTANT: For a consistent backup, stop the server before running this script.
powershell -NoProfile -Command "Compress-Archive -Path 'world' -DestinationPath ('backups\world-' + '%STAMP%' + '.zip') -Force"
echo Backup created in backups\
pause
