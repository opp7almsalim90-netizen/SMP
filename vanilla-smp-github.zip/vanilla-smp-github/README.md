# Vanilla SMP — Minecraft Java 1.21.11

A simple, command-enabled **vanilla** Minecraft Java server template. It uses the official vanilla server JAR—no mods or plugins.

## What's included

- `server.properties` — multiplayer, survival, difficulty, view distance, and other settings.
- `start.bat` — Windows start script.
- `start.sh` — Linux start script.
- `backup.bat` / `backup.sh` — create a timestamped world backup.
- `eula.txt.example` — EULA reminder/template.
- `.gitignore` — keeps server JARs, worlds, logs, and secrets out of Git.
- `ops.json.example` — example operator-file format (do not add real player UUIDs to a public repo).

## Important: GitHub is not a Minecraft host

This repository stores the server configuration and scripts. It does **not** run a server 24/7. Upload it to GitHub, then copy/download it onto a free Minecraft hosting provider that supports custom server properties, or run it on a computer. Free hosts may sleep when nobody is online and may have queues, RAM limits, or player limits.

## Requirements

- Minecraft **Java Edition 1.21.11** server software from the official Minecraft website.
- A compatible Java runtime. Minecraft 1.21.x generally requires **Java 21 or newer**; use the version specified by the official server download page.
- For a local server, enough RAM and a network setup that permits your friends to connect.

## Setup

### 1. Get the official server JAR

1. Open the official Minecraft server download page: https://www.minecraft.net/en-us/download/server
2. Download the server JAR for **Java Edition 1.21.11** if it is offered there.
3. Put it in this folder and rename it to `server.jar`.
4. Do not download server JARs from unofficial mirrors.

If the official page no longer offers that exact version, use the official Minecraft launcher/version information to obtain the matching official server software. The client and server versions should match.

### 2. Accept the EULA

1. Copy `eula.txt.example` to `eula.txt`.
2. Read the Minecraft EULA: https://www.minecraft.net/en-us/eula
3. Only if you agree, change `eula=false` to `eula=true` in `eula.txt`.

The first server launch may generate `eula.txt` automatically. If it does, edit the generated file instead.

### 3. Configure the server

Edit `server.properties` before first launch if you want. Defaults in this template:
- Survival mode
- Normal difficulty
- Online-mode authentication enabled
- Whitelist enabled
- PvP enabled
- 10-player limit (adjust to your host's actual capacity)

**Keep `online-mode=true`.** Turning it off can allow account impersonation on an improperly configured server.

### 4. Start it

**Windows:** double-click `start.bat`.

**Linux:** run:
```sh
chmod +x start.sh backup.sh
./start.sh
```

On a free host, follow that host's panel instructions instead of running these scripts if its panel starts the server for you.

### 5. Add yourself as an operator and whitelist players

Start the server once, then in its server console run:

```text
op YourMinecraftName
whitelist on
whitelist add YourMinecraftName
whitelist add FriendMinecraftName
```

Replace the example names with the exact Java Edition usernames. Operator permissions allow powerful commands, so only op trusted people.

Useful built-in vanilla commands:
```text
/help
/gamemode survival YourMinecraftName
/tp YourMinecraftName FriendMinecraftName
/time set day
/weather clear
/difficulty normal
/gamerule keepInventory true
/gamerule mobGriefing false
/whitelist list
/save-all
```

Some commands require operator permission. Run commands in the server console **without** the leading `/`; in the in-game chat, use `/`.

### 6. Connect

- On the same computer: `localhost`
- On the same home network: use the host computer's local IP.
- For friends outside your network: use the free host's server address, or configure networking on your own PC. Do not share your home IP publicly; port forwarding may expose your network. A reputable hosted server is usually simpler.

## Free-host notes

Before choosing a provider, check that it supports:
- Minecraft Java 1.21.11 specifically
- Vanilla server software
- Whitelist and operator commands
- Your expected player count
- Backups or world downloads

Do not put host panel passwords, tokens, personal IPs, or private player information in this public repository. Never commit `server.jar`, world folders, `ops.json`, `whitelist.json`, or `usercache.json`.

## Backups

Stop the server before backing up for the safest consistent copy.

- Windows: run `backup.bat`
- Linux: run `./backup.sh`

Backups are saved under `backups/`. Keep copies outside the server folder too.

## Troubleshooting

- **Java not found:** install a compatible Java runtime and make sure `java -version` works in your terminal.
- **Server exits immediately:** check `logs/latest.log`, the Java version, and whether `eula=true` is set after accepting the EULA.
- **Friends cannot join:** check the host's address, server status, whitelist, and host/network rules.
- **Version mismatch:** ensure the client, server JAR, and host software all use 1.21.11.

## License

Configuration and scripts in this repository are provided under the MIT License. Minecraft server software is not included and remains subject to Mojang/Microsoft's terms.
