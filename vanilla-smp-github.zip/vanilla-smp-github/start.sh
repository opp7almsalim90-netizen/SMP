#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

if [ ! -f server.jar ]; then
  echo "ERROR: server.jar was not found." >&2
  echo "Download the official Minecraft Java 1.21.11 server JAR and rename it server.jar." >&2
  exit 1
fi

exec java -Xms1G -Xmx2G -jar server.jar nogui
