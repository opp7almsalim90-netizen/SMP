@echo off
setlocal
cd /d "%~dp0"

if not exist "server.jar" (
  echo ERROR: server.jar was not found.
  echo Download the official Minecraft Java 1.21.11 server JAR and rename it server.jar.
  pause
  exit /b 1
)

echo Starting Vanilla SMP...
java -Xms1G -Xmx2G -jar server.jar nogui
echo.
echo Server stopped.
pause
